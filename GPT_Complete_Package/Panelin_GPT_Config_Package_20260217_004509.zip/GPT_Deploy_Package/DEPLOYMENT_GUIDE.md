# GPT Deployment Guide - Panelin

**Generated:** 2026-02-17T00:45:09.535536
**GPT Name:** Panelin - BMC Assistant Pro
**Version:** 2.5 Canonical - Full Capabilities + Accessories + BOM + Advanced Analysis + Enhanced PDF v2.0 + Wolf API KB Write (2026-02-14)

## 📋 Pre-Deployment Checklist

Before deploying, ensure:

✅ All required files are present

**Total Files:** 21
**Total Size:** 1.4 MB

## 🚀 Deployment Steps

1. Go to OpenAI GPT Builder (https://chat.openai.com/gpts/editor)
2. Click 'Create' to start a new GPT
3. Configure basic information:
   - Name: Use the 'name' field from this config
   - Description: Use the 'description' field from this config
4. Enable capabilities:
   - Web Browsing: Enabled
   - Code Interpreter: Enabled (CRITICAL for PDF generation)
   - Image Generation: Enabled
   - Canvas: Enabled
5. Add instructions:
   - Copy the 'instructions' field from this config
   - Paste into the Instructions box in GPT Builder
6. Add conversation starters:
   - Copy the 'conversation_starters' from this config
   - Add them one by one in GPT Builder
7. Upload knowledge base files:
   - See 'file_upload_sequence' below for exact order
   - CRITICAL: Follow phase order and pause times
8. (Optional) Configure Actions/API integration:
   - Import OpenAPI schema from 'Esquema json.rtf'
   - Configure API Key authentication
9. Test the GPT with verification queries
10. Publish the GPT (private or public as desired)

## 📂 File Upload Sequence

**CRITICAL:** Upload files in this exact order with pauses between phases.

### Phase 1: Master Knowledge Base **[CRITICAL]**

**Description:** Primary source of truth - UPLOAD FIRST

**Files to upload:**

- ✅ BMC_Base_Conocimiento_GPT-2.json (16.0 KB)
- ✅ bromyros_pricing_master.json (138.6 KB)
- ✅ accessories_catalog.json (47.5 KB)
- ✅ bom_rules.json (20.2 KB)

**⏱️ PAUSE 2-3 minutes after uploading this phase**

### Phase 2: Optimized Lookups **[CRITICAL]**

**Description:** Fast lookup indices and product catalogs

**Files to upload:**

- ✅ bromyros_pricing_gpt_optimized.json (128.9 KB)
- ✅ shopify_catalog_v1.json (741.9 KB)
- ✅ shopify_catalog_index_v1.csv (49.0 KB)

**⏱️ PAUSE 2 minutes after uploading this phase**

### Phase 3: Validation & Dynamic Data

**Description:** Cross-reference and web pricing snapshots

**Files to upload:**

- ✅ BMC_Base_Unificada_v4.json (10.6 KB)
- ✅ panelin_truth_bmcuruguay_web_only_v2.json (6.4 KB)

**⏱️ PAUSE 2 minutes after uploading this phase**

### Phase 4: Documentation & Guides

**Description:** Process guides and usage documentation

**Files to upload:**

- ✅ Aleros -2.rtf (461 B)
- ✅ panelin_context_consolidacion_sin_backend.md (1.1 KB)
- ✅ PANELIN_KNOWLEDGE_BASE_GUIDE.md (12.3 KB)
- ✅ PANELIN_QUOTATION_PROCESS.md (6.7 KB)
- ✅ PANELIN_TRAINING_GUIDE.md (6.7 KB)
- ✅ GPT_INSTRUCTIONS_PRICING.md (6.2 KB)
- ✅ GPT_PDF_INSTRUCTIONS.md (11.4 KB)
- ✅ GPT_OPTIMIZATION_ANALYSIS.md (10.4 KB)
- ✅ README.md (98.5 KB)

**⏱️ PAUSE 2 minutes after uploading this phase**

### Phase 5: Supporting Files

**Description:** Additional context and reference

**Files to upload:**

- ✅ Instrucciones GPT.rtf (7.5 KB)
- ✅ Panelin_GPT_config.json (31.5 KB)

**⏱️ PAUSE 2 minutes after uploading this phase**

### Phase 6: Assets

**Description:** Logo and brand assets

**Files to upload:**

- ✅ bmc_logo.png (47.9 KB)

**⏱️ PAUSE Complete minutes after uploading this phase**

## ✅ Verification

After deployment, test the GPT with these queries:

- "¿Cuánto cuesta ISODEC 100mm?"
- "¿Cuánto cuesta un gotero frontal?"
- "Necesito una cotización para Isopanel EPS 50mm de 5x10 metros"
- "Genera un PDF para una cotización"

## 📚 Additional Resources

- `gpt_deployment_config.json` - Complete configuration details
- `openai_gpt_config.json` - OpenAI-compatible format
- `validation_report.json` - File validation results
- `QUICK_REFERENCE.txt` - One-page quick reference

## 🔧 Troubleshooting

### Issue: File upload fails
**Solution:** Wait 1-2 minutes and try again. Check file size limits.

### Issue: GPT gives wrong prices
**Solution:** Verify Phase 1 files were uploaded first in correct order.

### Issue: PDF generation fails
**Solution:** Verify Code Interpreter is enabled and bmc_logo.png was uploaded.

### Issue: GPT can't find information
**Solution:** Wait 5 minutes for reindexing, then try again.

---

**Ready to deploy!** Follow the steps above to create your new GPT in OpenAI.